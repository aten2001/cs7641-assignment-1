require 'rexml/encodings/SHIFT-JIS'
